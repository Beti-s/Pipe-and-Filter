import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.*;

public class WordFrequencyProcessor {
    private static final Logger logger = Logger.getLogger(WordFrequencyProcessor.class.getName());

    public static void main(String[] args) {
        int port = 4000; // Default port for this server
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            logger.info("Server started. Listening on port " + port);

            while (true) {
                Socket socket = serverSocket.accept(); // Accept incoming connections
                logger.info("Accepted connection from " + socket.getInetAddress());
                new Thread(new FilterHandler(socket)).start(); // Handle each connection in a new thread
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Server encountered an error: ", e);
        }
    }
}

class FilterHandler implements Runnable {
    private static final Logger logger = Logger.getLogger(FilterHandler.class.getName());
    private Socket socket;

    public FilterHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            // Log the handling of the client
            logger.info("Handling client at " + socket.getInetAddress());

            // Read input from client
            String inputText = in.readLine();
            if (inputText == null || inputText.trim().isEmpty()) {
                logger.warning("Received empty or null input from client.");
                out.println("Error: No text provided");
                return;
            }

            // Process word frequency
            Map<String, Integer> wordFrequency = processWordFrequency(inputText);

            // Prepare and send response
            StringBuilder responseBuilder = new StringBuilder();
            for (Map.Entry<String, Integer> entry : wordFrequency.entrySet()) {
                responseBuilder.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
            }
            out.println(responseBuilder.toString());
            logger.info("Sent word frequency response to client at " + socket.getInetAddress());

        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error while handling client: ", e);
        } finally {
            try {
                socket.close();
                logger.info("Closed connection with client at " + socket.getInetAddress());
            } catch (IOException e) {
                logger.log(Level.WARNING, "Failed to close socket: ", e);
            }
        }
    }

    private Map<String, Integer> processWordFrequency(String input) {
        String[] words = input.split("\\s+");
        Map<String, Integer> frequencyMap = new HashMap<>();
        for (String word : words) {
            word = word.toLowerCase().replaceAll("[^a-z0-9]", ""); // Normalize case and remove punctuation
            if (!word.isEmpty()) {
                frequencyMap.put(word, frequencyMap.getOrDefault(word, 0) + 1);
            }
        }
        return frequencyMap;
    }
}
